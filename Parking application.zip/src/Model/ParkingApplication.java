
package Model;

public class ParkingApplication {
    
}
